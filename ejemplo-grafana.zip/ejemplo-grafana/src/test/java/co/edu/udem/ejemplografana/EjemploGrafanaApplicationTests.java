package co.edu.udem.ejemplografana;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EjemploGrafanaApplicationTests {

	@Test
	void contextLoads() {
	}

}

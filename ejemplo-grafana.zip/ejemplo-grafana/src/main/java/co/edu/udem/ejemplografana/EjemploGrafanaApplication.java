package co.edu.udem.ejemplografana;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EjemploGrafanaApplication {

	public static void main(String[] args) {
		SpringApplication.run(EjemploGrafanaApplication.class, args);
	}

}
